from vehicle import Vehicle

class Car(Vehicle):
    def __init__(self, color):
        super().__init__(color)
        self.has_winter_tires = False

    def set_winter_tires(self, has_winter_tires):
        self.has_winter_tires = has_winter_tires

    def __str__(self):
        return super().__str__() + f"\nHas winter tires: {self.has_winter_tires}"
