from truck import Truck
from garage import Garage

class GarageTester:

    @staticmethod
    def getExample():
        
        truck = Truck("black")
        truck.set_trailer(False)

        garage = Garage()
        garage.set_vehicle(truck)

       
        print(garage)


if __name__ == "__main__":
    GarageTester.getExample()
